#! /bin/bash
cd /home1/irteam/deploy/geo_life_infra
killall geo_life_infra
go build 
./geo_life_infra &