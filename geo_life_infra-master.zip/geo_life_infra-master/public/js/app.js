var geolifeinfraApp = angular.module('geolifeinfraApp', ['ngResource']);

geolifeinfraApp.controller('MainController', ['$rootScope', '$scope', 'Api', function MainController($rootScope, $scope, Api) {

  $scope.ui = {
    alert: {
      address: ''
    },
    card: {
      nav: { //card header
        items: [], // infra keywords
        activeItem: 0, // selected keyword index
        currentPage: 1,
        getClass: function(index) {
          return (index === this.activeItem) ? 'nav-link active' : 'nav-link';
        },
        selectItem: function(index) {
          console.log("hello");
          this.activeItem = index;

          $scope.ui.pagenation.page = 1;

          // fetch page data 
          var page = $scope.ui.pagenation.page; // current page
          var keyword = $scope.ui.card.nav.items[$scope.ui.card.nav.activeItem]; // current keyword
          var address = $scope.ui.alert.address; // current address
          $scope.api.getPagePlaces(page, keyword, address);
        }
      },
      listGroup: { // card body
        items: [], //places,
        activeItem: 0,
        selectItem: function(index) {
          this.activeItem = index;
          $scope.naverMap.openInfoWindow(index);
        }
      }
    },
    pagenation: {
      page: 1,
      selectPage: function(mode) {

        // fetch page data 
        // var page = $scope.ui.pagenation.page; // current page
        var keyword = $scope.ui.card.nav.items[$scope.ui.card.nav.activeItem]; // current keyword
        var address = $scope.ui.alert.address; // current address

        switch (mode) {
          case 'previous':
            if (this.page > 1) {
              this.page--;
              $scope.api.getPagePlaces(this.page, keyword, address);
            }
            break;
          case 'next':
            if (this.page >= 1) {
              this.page++;
              $scope.api.getPagePlaces(this.page, keyword, address);
            }
            break;
          default:
            return;
        }
      },
      getClass: function() {
        return (this.page === 1) ? 'page-item disabled' : 'page-item';
      }
    },
    modal: {
      input: '',
      addSave: function() {

        $scope.data.set('modalAdd');
        $scope.ui.set('modalAdd');

        // fetch page data 
        var page = $scope.ui.pagenation.page; // current page
        var keyword = this.input; // current keyword
        var address = $scope.ui.alert.address; // current address
        $scope.api.getPagePlaces(page, keyword, address);

      },
      delSave: function() {
        $scope.data.set('modalDel');
        $scope.ui.set('modalDel');
      }
    },
    set: function(api) {
      switch (api) {
        case 'init':
          this.alert.address = $scope.data.geolocation.r1 + " " + $scope.data.geolocation.r2 + " " + $scope.data.geolocation.r3;
          this.card.nav.items = $scope.data.infrakeywords;
          this.card.listGroup.items = $scope.data.items[this.card.nav.activeItem].places.items;
          break;
        case 'page':
          this.card.listGroup.items = $scope.data.items[this.card.nav.activeItem].places.items;
          break;
        case 'modalAdd':
          this.card.nav.items = $scope.data.infrakeywords;
          this.card.nav.activeItem = this.card.nav.items.length - 1;
          break;
        case 'modalDel':
          this.card.nav.items = $scope.data.infrakeywords;
          this.card.nav.activeItem = 0;
          $scope.ui.card.nav.selectItem(0);
          break;
        default:
          break;
      }
    }

  };

  $scope.data = {
    geolocation: {},
    items: [], // {infraKeyword: "", places: [...items: [...{title: "", address: ""...mapx: "", mapy:...}...]]}
    infrakeywords: [],
    set: function(api, d) {
      switch (api) {
        case 'init':
          this.geolocation = d.geolocation;
          this.items = d.items;
          this.infrakeywords = d.infrakeywords;
          break;
        case 'page':
          this.items[$scope.ui.card.nav.activeItem].places.items = d;
          break;
        case 'modalAdd':
          this.items.push({
            infraKeyword: $scope.ui.modal.input,
            places: {}
          });
          this.infrakeywords.push($scope.ui.modal.input);
          break;
        case 'modalDel':
          this.items.splice($scope.ui.card.nav.activeItem, 1);
          this.infrakeywords.splice($scope.ui.card.nav.activeItem, 1);
          break;
        default:
          break;
      }
    }
  }

  $scope.api = {
    getPagePlaces: function(page, keyword, address) {
      // params: page, keyword, area
      Api.getPagePlaces(page, keyword, address).then(function(data) {
        if (data.s === true) {
          if (data.result.items.length > 0) {
            // set data
            $scope.data.set('page', data.result.items[0].places.items);
            // set ui 
            $scope.ui.set('page');

            $scope.naverMap.setMarkers();

          }
        } else {
          //$scope.uiControls.addressAlert = "다음 페이지 가져오기 실패"
        }
      });
    },
    getInitPlaces: function() {
      Api.getInitPlaces().then(function(data) {
        if (data.s === true) {

          console.log(data);

          // set data
          $scope.data.set('init', data.result);
          // set ui
          $scope.ui.set('init');

          $scope.naverMap.setMarkers();

        } else {
          console.log('data get error');
        }
      });
    }
  }


  $scope.naverMap = {
    map: {},
    centerPosition: {},
    option: {},
    markers: [],
    panes: [],
    infoWindows: [],
    eventListeners: [],
    init: function() {
      this.centerPosition = new naver.maps.LatLng(37.3595704, 127.105399);
      this.option = {
        center: this.centerPosition,
        zoom: 12
      };
      this.map = new naver.maps.Map('map', this.option);
    },
    freeMap: function() {
      // free marker, event
      for (var i = 0; i < this.markers.length; i++) {
        this.markers[i].setMap(null);
        if (this.infoWindows[i].getMap()) {
          this.infoWindows[i].close();
        } 
      }

      naver.maps.Event.removeListener(this.eventListeners);

      this.markers = [];
      this.eventListeners = [];
      this.infoWindows = [];

    },
    setMarkers: function() {

      this.freeMap();

      for (var i = 0; i < $scope.ui.card.listGroup.items.length; i++) {
        var item = $scope.ui.card.listGroup.items[i];
        var position = this.getPosition(item.mapx, item.mapy);
        var marker = this.getMarker(position);
        this.markers.push(marker);
        this.setInfoWindows(i);
        if(i === 0) {
          this.setCenterPosition(marker.getPosition());
        }
      }
    },
    getPosition: function(mapx, mapy) {
      var placeLatLng = naver.maps.TransCoord.fromTM128ToLatLng(new naver.maps.Point(mapx, mapy));
      var position = new naver.maps.LatLng(placeLatLng.y, placeLatLng.x);
      return position;
    },
    getMarker: function(position) {
      return new naver.maps.Marker({
        position: position,
        map: this.map
      })
    },
    setCenterPosition: function(position) {
        this.map.setOptions('center', position);
    },
    setInfoWindows: function(i) {
      var title = $scope.ui.card.listGroup.items[i].title;
      var description = $scope.ui.card.listGroup.items[i].description;
      var content = '<div><p>' + title + '</p></div><div><small>' + description + '</small></div>';
      var infoWindow = new naver.maps.InfoWindow({
        content: content
      });
      this.infoWindows.push(infoWindow);

      var eventListener = naver.maps.Event.addListener(this.markers[i], "click", this.getClickHandler(i));
    },
    openInfoWindow: function(index) {
      this.map.setOptions('center', this.markers[index].getPosition());

      this.infoWindows[index].open(this.map, this.markers[index]);
    },
    getClickHandler: function(seq) {
      return function(e) {
        //$scope.uiControls.activeListGroupItem = seq;
        var marker = $scope.naverMap.markers[seq];
        var infoWindow = $scope.naverMap.infoWindows[seq];
        if (infoWindow.getMap()) {
          infoWindow.close();
        } else {
          infoWindow.open($scope.naverMap.map, marker);
        }
      };
    }
  }

  this.$onInit = function() {
    $scope.naverMap.init();
    $scope.api.getInitPlaces();
  }


}]);


// host 및 api url 
geolifeinfraApp.factory('Resource', ['$resource', function ResourceService($resource) {

  //var host = "http://10.66.70.83:8000";
  var host = "http://10.105.168.132:8000"

  return {
    initPlaces: $resource(host + '/init'),
    pagePlaces: $resource(host + '/page')
  };

}]);

// Resource를 사용하여 api 쿼리
geolifeinfraApp.service('Api', ['$q', 'Resource', function($q, Resource) {

  this.getInitPlaces = function() {
    var deferred = $q.defer();
    Resource.initPlaces.get().$promise.then(function(data) {
      if (data) {
        deferred.resolve({
          s: true,
          result: data
        });
      } else {
        deferred.resolve({
          s: false,
          msg: 'get data error'
        });
      }

    }, function(error) {
      console.log(error);
      deferred.resolve('error');
    });
    return deferred.promise;
  };

  this.getPagePlaces = function(pageNum, infraKeyword, area) {
    var deferred = $q.defer();
    Resource.pagePlaces.get({
      page: pageNum,
      infraKeyword: infraKeyword,
      area: area
    }).$promise.then(function(data) {
      if (data) {
        deferred.resolve({
          s: true,
          result: data
        });
      } else {
        deferred.resolve({
          s: false,
          msg: 'get data error'
        });
      }

    }, function(error) {
      console.log(error);
      deferred.resolve('error');
    });
    return deferred.promise;
  };

}]);


geolifeinfraApp.filter('tagFilter', function() {
  return function(x) {
    return x.replace(/<b>|<\/b>/g, '');
  };
});