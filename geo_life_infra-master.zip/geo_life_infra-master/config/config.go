package config

import (
	"encoding/json"
	"io/ioutil"
	"log"
)

type Config struct {
	NaverApi struct {
		ClientId       string `json:"clientId"`
		ClientSecret   string `json:"clientSecret"`
		PlaceSearchUrl string `json:"placeSearchUrl"`
	}
	NcpApi struct {
		ConsumerKey    string `json:"consumerKey"`
		ConsumerSecret string `json:"consumerSecret"`
	}
}

func GetConfig(path string) Config {
	var config Config
	f, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal(err)
	}

	err = json.Unmarshal(f, &config)
	if err != nil {
		log.Fatal(err)
	}

	return config
}
