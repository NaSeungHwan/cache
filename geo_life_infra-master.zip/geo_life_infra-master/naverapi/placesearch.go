package naverapi

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strconv"
	//"time"
)

var baseUrl = "https://openapi.naver.com/v1/search/local.json"

type PlaceSearchApi struct {
	requestParams requestParams
	QueryResult   QueryResult
	baseUrl       string
	clientId      string
	clientSecret  string

	client   *http.Client
	request  *http.Request
	urlQuery url.Values
}

type requestParams struct {
	query   string
	display int
	start   int
	sort    string
}

type QueryResult struct {
	// Rss string
	// Channel string
	LastBuildDate string `json:"lastBuildDate"`
	Total         int    `json:"total"`
	Start         int    `json:"start"`
	Display       int    `json:"display"`
	Category      string `json:"category"`
	Items         []Item `json:"items"`
}

type Item struct {
	Title       string `json:"title"`
	Link        string `json:"link"`
	Description string `json:"description"`
	Telephone   string `json:"telephone"`
	Address     string `json:"address"`
	RoadAddress string `json:"roadAddress"`
	Mapx        string `json:"mapx"`
	Mapy        string `json:"mapy"`
}

func GetPlaceSearchApiObj() PlaceSearchApi {
	var obj PlaceSearchApi
	obj.initObj()
	return obj
}

func (placeSearchApi *PlaceSearchApi) initObj() {
	placeSearchApi.requestParams.display = 10
	placeSearchApi.requestParams.start = 1
	placeSearchApi.requestParams.sort = "random"
}

func (placeSearchApi *PlaceSearchApi) SetApiConfig(clientId string, clientSecret string) {
	placeSearchApi.baseUrl = baseUrl
	placeSearchApi.clientId = clientId
	placeSearchApi.clientSecret = clientSecret
	placeSearchApi.InitConnection()
}

func (placeSearchApi *PlaceSearchApi) InitConnection() {
	placeSearchApi.client = &http.Client{}

	r, err := http.NewRequest("GET", placeSearchApi.baseUrl, nil)
	if err != nil {
		log.Fatal(err)
	}
	placeSearchApi.request = r
	placeSearchApi.request.Header.Set("X-Naver-Client-Id", placeSearchApi.clientId)
	placeSearchApi.request.Header.Set("X-Naver-Client-Secret", placeSearchApi.clientSecret)

	placeSearchApi.urlQuery = placeSearchApi.request.URL.Query()
	placeSearchApi.urlQuery.Add("query", "")
	placeSearchApi.urlQuery.Add("display", fmt.Sprintf("%d", placeSearchApi.requestParams.display))
	placeSearchApi.urlQuery.Add("start", fmt.Sprintf("%d", placeSearchApi.requestParams.start))
	placeSearchApi.urlQuery.Add("sort", placeSearchApi.requestParams.sort)

}

func (placeSearchApi *PlaceSearchApi) SetPage(pageNum string) {

	page, _ := strconv.Atoi(pageNum)
	placeSearchApi.urlQuery.Set("start", fmt.Sprintf("%d", placeSearchApi.requestParams.display*(page-1)+1))
}

func (placeSearchApi *PlaceSearchApi) SetRequestParams() {
	placeSearchApi.requestParams.start = 1
}

func (placeSearchApi *PlaceSearchApi) Query(query string) QueryResult {

	var result QueryResult

	placeSearchApi.urlQuery.Set("query", query)
	placeSearchApi.request.URL.RawQuery = placeSearchApi.urlQuery.Encode()
	//fmt.Println(placeSearchApi.request.URL.String())
	resp, err := placeSearchApi.client.Do(placeSearchApi.request)
	if err != nil {
		log.Println(err)
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Println(err)
	}
	defer resp.Body.Close()

	err = json.Unmarshal(body, &result)
	if err != nil {
		log.Println(err)
	}

	return result
}
