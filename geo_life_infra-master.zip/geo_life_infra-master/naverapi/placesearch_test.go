package naverapi

import (
	"../naverapi"
	"fmt"
	"testing"
)

func TestPlaceSearchApiQuery(t *testing.T) {
	clientId := ""
	clientSecret := ""

	placeSearchApi := naverapi.GetPlaceSearchApiObj()

	placeSearchApi.SetApiConfig(clientId, clientSecret)

	err := placeSearchApi.InitConnection()
	if err != nil {
		fmt.Println(err)
		return
	}

	placeSearchApi.Query("분당 정자동 치과")
}
