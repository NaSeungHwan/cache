package main

import (
	"fmt"
	"log"
	//"io/ioutil"
	//	"net/http"
	"encoding/json"
	"net"
	"net/http"

	c "./config"
	"./naverapi"
	"./ncpapi"
	// "io/ioutil"
)

type Resoponse struct {
	Geolocation   ncpapi.GeoLocation `json:"geolocation"`
	Items         []Item             `json:"items"`
	InfraKeywords []string           `json:"infrakeywords"`
}

type Item struct {
	InfraKeyword string               `json:"infraKeyword"`
	Places       naverapi.QueryResult `json:"places"`
}

var configPath = "./config.json"
var config c.Config
var geolocationApi ncpapi.GeolocationApi
var placeSearchApi naverapi.PlaceSearchApi
var infraKeywords []string

func init() {

	infraKeywords = []string{"병원", "마트", "약국", "은행", "헬스장", "공원"}

	config = c.GetConfig(configPath)

	geolocationApi = ncpapi.GetGeolocationApiObj()
	geolocationApi.SetApiConfig(config.NcpApi.ConsumerKey, config.NcpApi.ConsumerSecret)

	placeSearchApi = naverapi.GetPlaceSearchApiObj()
	placeSearchApi.SetApiConfig(config.NaverApi.ClientId, config.NaverApi.ClientSecret)
}

func main() {

	// handle static files
	http.Handle("/", http.FileServer(http.Dir("./public/view")))
	http.Handle("/js/", http.StripPrefix("/js", http.FileServer(http.Dir("./public/js"))))
	http.Handle("/css/", http.StripPrefix("/css", http.FileServer(http.Dir("./public/css"))))

	// handle api call
	http.HandleFunc("/init", initApiHandler)
	http.HandleFunc("/page", pageApiHandler)

	// start server
	log.Fatal(http.ListenAndServe(":8000", nil))
}

func pageApiHandler(w http.ResponseWriter, r *http.Request) {

	var response Resoponse

	area := r.URL.Query().Get("area")
	infraKeyword := r.URL.Query().Get("infraKeyword")
	pageNum := r.URL.Query().Get("page")

	// fmt.Println(area)
	// fmt.Println(infraKeyword)
	// fmt.Println(pageNum)

	placeSearchApi.SetPage(pageNum)

	item := Item{
		InfraKeyword: infraKeyword,
		Places:       placeSearchApi.Query(area + " " + infraKeyword),
	}

	response.Items = append(response.Items, item)

	responseJson, err := json.Marshal(response)
	if err != nil {
		fmt.Fprintf(w, "%s", "get data error")
	}

	fmt.Fprintf(w, "%s", responseJson)

}

func initApiHandler(w http.ResponseWriter, r *http.Request) {

	placeSearchApi.SetPage("1")

	var response Resoponse

	// 1. get source ip from http request
	ip, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		fmt.Fprintf(w, "userip: %q is not IP:port", r.RemoteAddr)
	}
	fmt.Println(ip)
	//ip = "143.248.142.77"

	// 2. get geolocation
	geolocationResult := geolocationApi.Query(ip)
	if geolocationResult.ReturnCode != 0 {
		fmt.Fprintf(w, "geolocation error: \n returnCode: %d, \n "+
			"returnMessage: %s", geolocationResult.ReturnCode, geolocationResult.ReturnMessage)
		return
	}

	fmt.Println(geolocationResult)

	response.Geolocation = geolocationResult.GeoLocation
	response.InfraKeywords = infraKeywords

	// 3. query naver search place api
	area := fmt.Sprintf("%s %s", geolocationResult.GeoLocation.R2,
		geolocationResult.GeoLocation.R3)

	for _, v := range infraKeywords {
		var item Item
		item.InfraKeyword = v
		item.Places = placeSearchApi.Query(area + " " + v)
		response.Items = append(response.Items, item)
	}

	// 4. marshal response and return
	responseJson, err := json.Marshal(response)
	if err != nil {
		fmt.Fprintf(w, "%s", "get data error")
	}

	fmt.Fprintf(w, "%s", responseJson)

}
