package ncpapi

import (
	"encoding/json"
	"fmt"
	"github.com/dghubble/oauth1"
	"io/ioutil"
	"net/http"
	"strconv"
)

type GeolocationApi struct {
	consumerKey        string
	consumerSecret     string
	baseUrl            string
	ip                 string
	enc                string
	ext                string
	responseFormatType string
	oauthConfig        *oauth1.Config
	oauthToken         *oauth1.Token
	httpClient         *http.Client
}

type QueryResult struct {
	ReturnCode    int         `json:"returnCode, omitempty"`
	ReturnMessage string      `json:"returnMessage, omitempty"`
	RequestId     string      `json:"requestId, omitempty"`
	GeoLocation   GeoLocation `json:"geoLocation, omitempty"`
}

type GeoLocation struct {
	Country string  `json:"country"`
	Code    string  `json:"code"`
	R1      string  `json:"r1"`
	R2      string  `json:"r2"`
	R3      string  `json:"r3"`
	Lat     float64 `json:"lat"`
	Long    float64 `json:"long"`
	Net     string  `json:"net"`
}

type queryFailed struct {
	ReturnCode    string `json:"returnCode"`
	ReturnMessage string `json:"returnMessage"`
}

func (geoApi *GeolocationApi) initObj() {
	geoApi.baseUrl = "https://api.ncloud.com/geolocation/?action=geolocation"
	geoApi.enc = "utf8"
	geoApi.ext = "t"
	geoApi.responseFormatType = "json"
}

func GetGeolocationApiObj() GeolocationApi {
	var obj GeolocationApi
	obj.initObj()
	return obj
}

func (geoApi *GeolocationApi) SetApiConfig(consumerKey, consumerSecret string) {
	geoApi.consumerKey = consumerKey
	geoApi.consumerSecret = consumerSecret
	geoApi.oauthConfig = oauth1.NewConfig(geoApi.consumerKey, geoApi.consumerSecret)
	geoApi.oauthToken = oauth1.NewToken("", "")
	geoApi.httpClient = geoApi.oauthConfig.Client(oauth1.NoContext, geoApi.oauthToken)
}

func (geoApi *GeolocationApi) getBaseString() (baseString string) {
	baseString = geoApi.baseUrl + "&ip=" + geoApi.ip + "&enc=" + geoApi.enc +
		"&ext=" + geoApi.ext + "&responseFormatType=" + geoApi.responseFormatType
	return
}

func (geoApi *GeolocationApi) Query(ip string) QueryResult {
	var result QueryResult

	geoApi.ip = ip
	baseString := geoApi.getBaseString()

	resp, _ := geoApi.httpClient.Get(baseString)
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)

	// query 성공 및 실패시의 returnCode 값의 타입 불일치, api 수정 필요
	err := json.Unmarshal(body, &result)
	if err != nil {
		var failed queryFailed
		err = json.Unmarshal(body, &failed)
		if err != nil {
			fmt.Println(err)
		}
		result.ReturnCode, err = strconv.Atoi(failed.ReturnCode)
		if err != nil {
			fmt.Println(err)
		}

		result.ReturnMessage = failed.ReturnMessage

		return result
	}

	return result
}
