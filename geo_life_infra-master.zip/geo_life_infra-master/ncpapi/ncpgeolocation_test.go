package ncpapi

import (
	"../ncpapi"
	"testing"
)

func TestGeolocationApiQuery(t *testing.T) {
	consumerKey := ""
	consumerSecret := ""
	ip := "143.248.142.77"
	geolocationApi := ncpapi.GetGeolocationApiObj()
	geolocationApi.SetApiConfig(consumerKey, consumerSecret)
	geolocationApi.Query(ip)
}
