package main

import
(
	"fmt"
	"log"
	"io"
	"io/ioutil"
	"os"
	c "./conf"
	"./ncpapi"
	"encoding/json"
	"net"
	"net/http"
	"strings"
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
)

/* 향섭님 geo_life_infra geolocation api call 참조 */

type Geolocation struct {
	Geolocation ncpapi.GeoLocation	`json:"geolocation"`
	Ip          string  		`json:"ip"`
}

type Country struct {
	Country string  `json:"country"`
	Count   int     `json:"count"`
}

type Agency struct {
	Agency  string  `json:"agency"`
	Count   int     `json:"count"`
}

type Response struct {
	Location        []Country	`json:"location"`
	Agencies        []Agency	`json:"agencies"`
}

var locationObj         map[string]int
var agencyObj           map[string]int
var geolocationApi      ncpapi.GeolocationApi
var configPath = "conf/NCPKey.json"
var config c.Config

func init() {
	locationObj = make(map[string]int)
	agencyObj = make(map[string]int)
	config = c.GetConfig(configPath)
	geolocationApi = ncpapi.GetGeolocationApiObj()
	geolocationApi.SetApiConfig(config.NcpApi.ConsumerKey, config.NcpApi.ConsumerSecret)

	/* data load, 간단한 데모를 위한 data 보관용도 */
	db := conn()
	rows, err := db.Query("SELECT * FROM location")
	CheckErr(err)
	for rows.Next() {
		var location    string
		var count       int
		err = rows.Scan(&location, &count)
		CheckErr(err)
		locationObj[location] = count
	}
	rows, err = db.Query("SELECT * FROM agencies")
	CheckErr(err)
	for rows.Next() {
		var agency      string
		var count       int
		err = rows.Scan(&agency, &count)
		CheckErr(err)
		agencyObj[agency] = count
	}
	defer db.Close()
}

func CheckErr(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

/* db connection, 변수 사용 방법..? */
func conn() (db *sql.DB){
	db, err := sql.Open("mysql", "username:passwd@tcp(127.0.0.1:3306)/slab_geo")
	CheckErr(err)
	err = db.Ping()
	CheckErr(err)

	return db
}

func main() {
	/* log */
	fpLog, err := os.OpenFile("logfile.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil { panic(err) }
	defer fpLog.Close()
	multiWriter := io.MultiWriter(fpLog, os.Stdout)
	log.SetOutput(multiWriter)

	/* Set Handler */
	http.HandleFunc("/", rootHandler)
	http.Handle("/js/", http.StripPrefix("/js", http.FileServer(http.Dir("./front/js"))))
	http.Handle("/css/", http.StripPrefix("/css", http.FileServer(http.Dir("./front/css"))))
	http.HandleFunc("/geolocation", geoApiHandler)
	http.HandleFunc("/getCount", getGeoStat)

	/* Listen 8009 Port */
	log.Fatal(http.ListenAndServe(":8009", nil))
}

func rootHandler (w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html")
	w.Header().Set("Server", "S-Lab/geo 1.1")
	data, err := ioutil.ReadFile("../front/html/index.html")
	if err != nil {
		panic(err)
	}
	w.Header().Set("Content-Length", fmt.Sprint(len(data)))
	fmt.Fprint(w, string(data))
}

func geoApiHandler(w http.ResponseWriter, r *http.Request) {
	var response Geolocation

	db := conn()

	setCorsHeader(w, r)
	/* get remote addr */
	ip, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		fmt.Fprintf(w, "userip: %q is not IP:port", r.RemoteAddr)
	}

	/* call geolocation api using ip */
	geolocationResult := geolocationApi.Query(ip)
	if geolocationResult.ReturnCode != 0 {
		fmt.Fprintf(w, "geolocation error: \n returnCode: %d, \n "+
			"returnMessage: %s", geolocationResult.ReturnCode, geolocationResult.ReturnMessage)
		return
	}
	/* count location & agency */
	response.Geolocation = geolocationResult.GeoLocation
	response.Ip = ip

	location := strings.Split(geolocationResult.GeoLocation.R2, " ")
	locationObj[location[0]] += 1
	agencyObj[geolocationResult.GeoLocation.Net] += 1
	log.Printf("%s : %d, %s : %d [%s]", location[0], locationObj[location[0]],
		geolocationResult.GeoLocation.Net, agencyObj[geolocationResult.GeoLocation.Net], ip)

	/* insert db */
	stmt, err := db.Prepare("INSERT agencies SET agency=?, count=? ON DUPLICATE KEY UPDATE agency=?, count=?")
	CheckErr(err)

	res, err := stmt.Exec(geolocationResult.GeoLocation.Net, agencyObj[geolocationResult.GeoLocation.Net],
		geolocationResult.GeoLocation.Net, agencyObj[geolocationResult.GeoLocation.Net])
	CheckErr(err)
	defer stmt.Close()

	log.Printf("insert : %s", res)

	stmt, err = db.Prepare("INSERT location SET country=?, count=? ON DUPLICATE KEY UPDATE country=?, count=?")
	CheckErr(err)

	res, err = stmt.Exec(location[0], locationObj[location[0]],
		location[0], locationObj[location[0]])
	CheckErr(err)
	defer stmt.Close()

	responseJson, err := json.Marshal(response)
	if err != nil {
		fmt.Fprintf(w, "%s", "data access error")
	}
	fmt.Fprintf(w, "%s", responseJson)
	defer db.Close()
}

func getGeoStat(w http.ResponseWriter, r *http.Request)  {
	var response    Response

	setCorsHeader(w, r)
	for k := range locationObj {
		var location    Country
		location.Country = k
		location.Count = locationObj[k]
		response.Location = append(response.Location, location)
	}
	for k := range agencyObj {
		var agency      Agency
		agency.Agency = k
		agency.Count = agencyObj[k]
		response.Agencies = append(response.Agencies, agency)
	}

	responseJson, err := json.Marshal(response)
	if err != nil {
		fmt.Fprintf(w, "%s", "get data error")
	}
	fmt.Fprintf(w, "%s", responseJson)
}

func setCorsHeader(w http.ResponseWriter, r *http.Request) {
	if origin := r.Header.Get("Origin"); origin != "" {
		w.Header().Set("Access-Control-Allow-Origin", origin)
		fmt.Println(origin)
	}
	w.Header().Set("Server", "S-Lab/geo 1.1")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token")
}
