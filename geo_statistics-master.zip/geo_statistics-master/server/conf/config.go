package conf

import (
	"encoding/json"
	"io/ioutil"
	"log"
)

type Config struct {
	NcpApi struct {
		ConsumerKey    string `json:"consumerKey"`
		ConsumerSecret string `json:"consumerSecret"`
	}
	DBInfo struct {
		User    string `json:"user"`
		Passwd	string `json:"passwd"`
	}
}

func GetConfig(path string) Config {
	var config Config
	f, err := ioutil.ReadFile(path)
	if err != nil {
		log.Fatal(err)
	}
	err = json.Unmarshal(f, &config)
	if err != nil {
		log.Fatal(err)
	}

	return config
}